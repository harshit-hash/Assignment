﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Configuration;
using MySql.Data.MySqlClient;

public partial class Registration : System.Web.UI.Page
{
    dbcon objConn = new dbcon();
    protected void Page_Load(object sender, EventArgs e)
    {
        try { if (!IsPostBack) {
                string SltUsr = "select name,email, psw from reg ORDER BY name DESC LIMIT 1";
                objConn.RetriveDS(SltUsr);
                if (objConn.dsCommon.Tables[0].Rows.Count != 0)
                {
                    LblName.Text = objConn.dsCommon.Tables[0].Rows[0]["name"].ToString();
                    LblEmail.Text = objConn.dsCommon.Tables[0].Rows[0]["email"].ToString();
                    LblPsw.Text = objConn.dsCommon.Tables[0].Rows[0]["psw"].ToString();


                }
                    clearcontrol(); } }
        catch (Exception Err)
        {
            string ErrMsg = Err.Message.ToString().Replace("'", "");
            ScriptManager.RegisterClientScriptBlock(this, typeof(Page), "alert", "<script>alert('" + ErrMsg + "');</script>", false);
        }

    }
    protected void BtnReg_Click(object sender, EventArgs e)
    {
        try
        {
            if (TxtEmail.Text.Trim() == "")
            {
                ScriptManager.RegisterClientScriptBlock(this, typeof(Page), "alert", "<script>alert('Please Enter Your Email-Id')</script>", false);
            }
            else if (TxtName.Text.Trim() == "")
            {
                ScriptManager.RegisterClientScriptBlock(this, typeof(Page), "alert", "<script>alert('Please Enter Your Name')</script>", false);
            }
            else if (TxtPsw.Text.Trim() == "")
            {
                ScriptManager.RegisterClientScriptBlock(this, typeof(Page), "alert", "<script>alert('Please Enter Your Password')</script>", false);
            }
            else if (TxtConPsw.Text.Trim() == "")
            {
                ScriptManager.RegisterClientScriptBlock(this, typeof(Page), "alert", "<script>alert('Please Confirm Your Password')</script>", false);
            }
            else if (TxtPsw.Text.Length < 8)
            {
                ScriptManager.RegisterClientScriptBlock(this, typeof(Page), "alert", "<script>alert('Password Must be atleast 8')</script>", false);

            }
            else
            {
                objConn.conPGeKosh = new MySqlConnection(objConn.csPG);
                if (objConn.conPGeKosh.State == ConnectionState.Closed)
                {
                    objConn.conPGeKosh.Open();
                    //return;
                }
                string InsUsr = "insert into reg(name, email, psw) values(@name,@email,@psw) ";
                objConn.cmdPG = new MySqlCommand(InsUsr, objConn.conPGeKosh);
                objConn.cmdPG.Parameters.AddWithValue("name", TxtName.Text.Trim());
                objConn.cmdPG.Parameters.AddWithValue("email", TxtEmail.Text.Trim());
                objConn.cmdPG.Parameters.AddWithValue("psw", TxtPsw.Text.Trim());
                objConn.cmdPG.ExecuteNonQuery();
                ScriptManager.RegisterStartupScript(this, this.GetType(), "alert", "<script>alert('Successfull register')</script>", false);
                clearcontrol();


            }
        }
        catch (Exception Err)
        {
            string ErrMsg = Err.Message.ToString().Replace("'", "");
            ScriptManager.RegisterClientScriptBlock(this, typeof(Page), "alert", "<script>alert('" + ErrMsg + "');</script>", false);
        }
        

    }
    public void clearcontrol()
    {
        TxtName.Text = "";
        TxtEmail.Text = "";
        TxtPsw.Text = "";
        TxtConPsw.Text = "";
    }
   
}