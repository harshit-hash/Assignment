﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Home : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        try { if (!IsPostBack)
            {
                TxtNo1.Text = "";
                LblAns.Text = "";
            } 
        }
        catch (Exception Err)
        {
            string ErrMsg = Err.Message.ToString().Replace("'", "");
            ScriptManager.RegisterClientScriptBlock(this, typeof(Page), "alert", "<script>alert('" + ErrMsg + "');</script>", false);
        }

    }

    protected void BtnReg_Click(object sender, EventArgs e)
    {
        try
        {
            if (TxtNo1.Text.Trim() == "") { ScriptManager.RegisterClientScriptBlock(this, typeof(Page), "alert", "<script>alert('Please Enter First Number')</script>", false); }
            
            else
            {

                LblAns.Text = "";
                int n, min, max, count = 0, f3 = 0, f2 = 0;
                n = Int16.Parse(TxtNo1.Text.Trim());
                if (n % 50 == 0)
                {
                   
                    if (n >= 50 || n<=10000)
                    {
                        max = n / 50;
                        for (int i = 0; i < 10; i++)
                        {
                            if (n >= 2000)
                            {
                                n = n - 2000;
                                count++;

                            }

                            else if (n<2000 && n >= 500)
                            {
                                n = n - 500;
                                count++;

                            }
                            else if (n < 500 && n >= 200)
                            {
                                n = n - 200;
                                count++;
                            }
                            else if (n < 200 && n >= 100)
                            {
                                n = n - 200;
                                count++;
                            }
                            else if (n < 100 && n >= 50)
                            {
                                n = n - 200;
                                count++;
                            }
                            else if (n < 50)
                            {
                                break;
                            }


                        }
                        min = count;

                        LblAns.Text = "Min: " + min.ToString() + " max: " + max.ToString();
                        
                    }
                    else { }
                }
                else
                {
                    ScriptManager.RegisterClientScriptBlock(this, typeof(Page), "alert", "<script>alert('Withdrawal money is not available')</script>", false);

                }
                
            }
        }
        catch (Exception Err)
        {
            string ErrMsg = Err.Message.ToString().Replace("'", "");
            ScriptManager.RegisterClientScriptBlock(this, typeof(Page), "alert", "<script>alert('" + ErrMsg + "');</script>", false);
        }

    }
}